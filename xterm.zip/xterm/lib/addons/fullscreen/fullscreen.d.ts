import { Terminal } from 'xterm';
export declare function toggleFullScreen(term: Terminal, fullscreen: boolean): void;
export declare function apply(terminalConstructor: typeof Terminal): void;
